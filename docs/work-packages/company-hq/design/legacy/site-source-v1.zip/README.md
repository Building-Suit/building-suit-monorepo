# Building Suit — Company HQ

Private cloud headquarters for the existing CEO and HR Lead. The original isometric office artwork adapts the founder's preferred reference style; company hierarchy, scope, approvals and learning rules remain unchanged.

## What works

- CEO/HR conversations saved in cloud storage; messages wait for a real assistant reply.
- Task proposals, founder approval, cancellation, owner-scoped progress and recorded deliverable/review evidence.
- Activity and office status derived from actual records.
- A small reviewed Brain policy summary. The assistant must read the current authorized Drive Brain separately before answering company questions.
- Site MCP tools for the existing assistant: `hq_get_state`, `hq_reply`, `hq_update_task`.

Only CEO `AG-CEO-001` and HR Lead `AG-HR-001` exist. The earlier accepted HR-001 assessment is imported as a historical record, with its review limitation preserved.

## Run locally

Requires Node 22.13+ with `node:sqlite`; there are no installed dependencies.

```text
node scripts/build.mjs
node --test tests/hq.test.mjs
node scripts/validate-artifact.mjs
node scripts/dev.mjs
```

Open `http://127.0.0.1:8787`. The loopback-only development adapter injects a local founder identity. Production requires Sites' authenticated identity headers. Local data lives in ignored `.sites-runtime/hq.sqlite` and is never packaged.

## On-demand agent workflow

1. Discuss work in the CEO office. The website durably queues the message.
2. In an authorized assistant with the HQ plugin connected, ask it to check HQ. It calls `hq_get_state` and reads the current Brain via its separate authorized file access.
3. The assistant performs only the scoped authorized work, posts a genuine reply with `hq_reply`, and maintains useful work learning in the Brain.
4. A task must be explicitly approved in the website before the assistant can move it to `running`. Recorded states are queued → running → review → completed, with blocked/failed paths. Completion requires a deliverable and recorded review evidence. Review independence is a trusted assistant procedure, not independently verified reviewer identity in this app.

The bridge is pull-based. The website does not launch models, read this Drive folder directly, or operate agents continuously. No scheduler or autonomous execution service is installed.

## Cost boundary

The implementation has no external model calls, paid fallback, subscriptions, generation calls or paid API keys. Task budgets are fixed at zero, enforced in API and database. Original SVG artwork needs no generation service. OpenHiggsfield remains an available Brain skill, inactive here because provider generation has not been approved as free.

Sites and the existing assistant still have their account allowances and platform limits. This implementation does not establish unlimited free hosting or unlimited free inference. Do not add paid services or increase budgets without the founder's explicit approval.

## Deployment

The source manifest `.openai/hosting.json` binds this checkout to its existing owner-private Site and its D1 storage. Keep its project ID stable. Use the Sites skill's `site-workflow.mjs` helper to build, synchronize source, and package the exact commit, then publish using the native private deployment tool. Never store credentials in files, command arguments or logs.

The canonical backend is `worker/index.js`; `scripts/build.mjs` embeds `src/ui.html` in `dist/server/index.js`. Schema migrations live in `drizzle/`. Once deployed, add migrations rather than editing applied migrations. The local D1 adapter tests transaction rollback and workflow constraints but does not substitute for checking the actual hosted deployment.
