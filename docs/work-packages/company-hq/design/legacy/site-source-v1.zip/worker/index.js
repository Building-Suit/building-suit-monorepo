const HTML = /*__HQ_HTML__*/ "";
const ROLES = [
 {id:"ceo",name:"CEO",role:"Executive Office",onDemand:true,description:"Your thinking partner and coordinator. Plans with you, delegates within approved scope and reviews actual results.",skills:["Planning","Company evidence","Delegation","Deliverable review","Work learning"]},
 {id:"hr",name:"HR Lead",role:"HR & Agent Development",onDemand:true,description:"Assesses capability gaps, researches candidates and recommends the smallest effective agent workforce.",skills:["Recruitment","Skill assessment","Workforce planning","Agent records"]}
];
const NOTES = [
 {title:"Founder authority",text:"You remain the final authority. New spending, publishing, external messages and expanded access require their applicable authorization."},
 {title:"Current workforce",text:"CEO AG-CEO-001 and HR Lead AG-HR-001. Both operate on demand. HR recruitment, evaluation and archive functions are capabilities of the existing HR role."},
 {title:"Work learning",text:"Save supported facts, corrections and decisions from substantive work discussions. Watching a reference or casual chat stays temporary unless an explicit scoped save is requested."},
 {title:"Zero-spend boundary",text:"No paid model calls, media generation, paid fallback or new subscriptions are connected. A task cannot carry a budget above zero."},
 {title:"Completion means evidence",text:"Task progress comes from recorded actions. A deliverable and review evidence are required before completion; animation alone establishes no work."}
];
const VALID_ROLES = new Set(["ceo","hr"]);
const TRANSITIONS = {queued:["running","blocked","failed"],running:["review","blocked","failed"],review:["running","completed","blocked","failed"],blocked:["queued","failed"],failed:[],completed:[],cancelled:[]};
class Problem extends Error {constructor(status,message){super(message);this.status=status;}}
function response(data,status=200){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});}
function field(v,name,max=4000){if(typeof v!=="string"||!v.trim()||v.length>max)throw new Problem(400,`${name} is required (maximum ${max} characters).`);return v.trim();}
function role(v){if(!VALID_ROLES.has(v))throw new Problem(400,"Choose CEO or HR.");return v;}
function id(v){if(typeof v!=="string"||!/^[-a-zA-Z0-9_]{1,120}$/.test(v))throw new Problem(400,"Invalid record identifier.");return v;}
const stamp=()=>new Date().toISOString();
const uid=(prefix)=>`${prefix}_${crypto.randomUUID().replaceAll("-","")}`;
function identity(request){const user=request.headers.get("oai-authenticated-user-id");if(!user)throw new Problem(401,"Sign in to your private Company HQ.");return user;}
function sameOrigin(request){const origin=request.headers.get("origin");if(origin!==new URL(request.url).origin)throw new Problem(403,"This action must come from your HQ.");}
async function body(request){const len=Number(request.headers.get("content-length")||0);if(len>18000)throw new Problem(413,"Request is too large.");const text=await request.text();if(text.length>18000)throw new Problem(413,"Request is too large.");try{return JSON.parse(text);}catch{throw new Problem(400,"Send valid JSON.");}}
const stmt=(db,sql,...params)=>db.prepare(sql).bind(...params);
async function all(db,sql,...params){return (await stmt(db,sql,...params).all()).results||[];}
async function one(db,sql,...params){return stmt(db,sql,...params).first();}
function event(db,agent,type,title,detail,key,time=stamp()){return stmt(db,"INSERT OR IGNORE INTO events(id,agent,type,title,detail,created_at,source_key) VALUES(?,?,?,?,?,?,?)",uid("evt"),agent,type,title,detail,time,key);}
async function seed(db){
 if(await one(db,"SELECT value FROM settings WHERE key='initialized'"))return;
 const date="2026-11-03";
 await db.batch([
  stmt(db,"INSERT OR IGNORE INTO tasks(id,title,brief,owner,status,acceptance,allowed_actions,budget,deliverable,review_evidence,approved_at,approval_source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)","HR-001","Company HQ staffing assessment","Assess the smallest team and skill set needed for Company HQ.","hr","completed","Bounded primary-source research and independent artifact review.","Read scoped company notes; research public sources; prepare staffing report.",0,"Recommend one temporary HQ Builder, existing CEO/HR and a separate review invocation. No additional department is justified yet.","Independent review accepted criteria 1–5. Full execution-history/write-exclusivity audit was unavailable; that limitation remains recorded.",date,"Founder approved the initial HR build and supervised staffing assignment.",date,date),
  event(db,"hr","review","First HR assignment reviewed","The actual staffing report received independent source and artifact review. No new employee was hired.","seed-hr-reviewed",date),
  stmt(db,"INSERT OR IGNORE INTO settings(key,value) VALUES('initialized','1')")
 ]);
}
function taskRow(r){return {id:r.id,title:r.title,brief:r.brief,owner:r.owner,status:r.status,acceptance:r.acceptance,allowedActions:r.allowed_actions,budget:r.budget,deliverable:r.deliverable,reviewEvidence:r.review_evidence,approvedAt:r.approved_at,approvalSource:r.approval_source,createdAt:r.created_at,updatedAt:r.updated_at};}
async function state(db){
 const [taskRows,messageRows,eventRows,seen]=await Promise.all([all(db,"SELECT * FROM tasks ORDER BY created_at DESC LIMIT 150"),all(db,"SELECT * FROM messages ORDER BY created_at DESC LIMIT 180"),all(db,"SELECT * FROM events ORDER BY created_at DESC LIMIT 80"),one(db,"SELECT value FROM settings WHERE key='last_agent_seen'")]);
 const tasks=taskRows.map(taskRow);
 return {ok:true,agents:ROLES.map(r=>({...r,status:tasks.some(t=>t.owner===r.id&&t.status==="running")?"working":tasks.some(t=>t.owner===r.id&&t.status==="review")?"reviewing":"idle"})),tasks,messages:messageRows.reverse().map(r=>({id:r.id,agent:r.agent,role:r.role,text:r.text,status:r.status,createdAt:r.created_at})),events:eventRows.map(r=>({id:r.id,agent:r.agent,type:r.type,title:r.title,detail:r.detail,createdAt:r.created_at})),brain:{name:"Company Brain",source:"Founder’s maintained Drive Brain",connection:"assistant_bridge",updatedAt:"2026-11-03",notes:NOTES},connection:{executor:"on_demand",connected:!!seen&&Date.now()-Date.parse(seen.value)<120000,lastAgentSeen:seen?.value||null},cost:{paidCallsEnabled:false,limit:0}};
}
async function cached(db,key){const row=await one(db,"SELECT result FROM actions WHERE id=?",key);return row?JSON.parse(row.result):null;}
async function recordAction(db,key,result,statements){await db.batch([...statements,stmt(db,"INSERT INTO actions(id,result,created_at) VALUES(?,?,?)",key,JSON.stringify(result),stamp())]);return result;}
async function founderAction(db,input){
 const key=field(input.idempotencyKey,"Request key",100);const prior=await cached(db,key);if(prior)return prior;
 const now=stamp();
 if(input.action==="send_message"){
  const agent=role(input.agent),text=field(input.text,"Message",6000),mid=uid("msg");const result={ok:true,id:mid,status:"queued"};
  return recordAction(db,key,result,[stmt(db,"INSERT INTO messages(id,agent,role,text,status,created_at,request_key) VALUES(?,?,?,?,?,?,?)",mid,agent,"founder",text,"queued",now,key),event(db,agent,"message","Message saved",`Your message is waiting for ${agent==="ceo"?"the CEO":"HR"}.`,key,now)]);
 }
 if(input.action==="create_task"){
  const owner=role(input.owner),title=field(input.title,"Title",180),brief=field(input.brief,"Outcome",5000),acceptance=field(input.acceptance,"Definition of done",3000),allowed=field(input.allowedActions,"Allowed actions",3000);
  if(input.budget!==undefined&&input.budget!==0)throw new Problem(400,"Only zero-budget tasks are supported.");
  const tid=uid("task"),result={ok:true,id:tid,status:"proposed"};
  return recordAction(db,key,result,[stmt(db,"INSERT INTO tasks(id,title,brief,owner,status,acceptance,allowed_actions,budget,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",tid,title,brief,owner,"proposed",acceptance,allowed,0,now,now),event(db,owner,"plan","Plan ready for approval",title,key,now)]);
 }
 if(input.action==="approve_task"||input.action==="cancel_task"){
  const tid=id(input.id),task=await one(db,"SELECT * FROM tasks WHERE id=?",tid);if(!task)throw new Problem(404,"Task was not found.");
  if(input.action==="approve_task"){
   if(task.status!=="proposed")throw new Problem(409,"Only a proposed plan can be approved.");
   return recordAction(db,key,{ok:true,id:tid,status:"queued"},[stmt(db,"UPDATE tasks SET status='queued',approved_at=?,approval_source='Founder approved in Company HQ',updated_at=? WHERE id=?",now,now,tid),event(db,task.owner,"approval","Plan approved",task.title,key,now)]);
  }
  if(["completed","cancelled"].includes(task.status))throw new Problem(409,"This task is already closed.");
  return recordAction(db,key,{ok:true,id:tid,status:"cancelled"},[stmt(db,"UPDATE tasks SET status='cancelled',updated_at=? WHERE id=?",now,tid),event(db,task.owner,"cancel","Task cancelled",task.title,key,now)]);
 }
 throw new Problem(400,"Unknown founder action.");
}
async function agentAction(db,name,args){
 const now=stamp();
 if(name==="hq_get_state"){await stmt(db,"INSERT INTO settings(key,value) VALUES('last_agent_seen',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",now).run();return state(db);}
 const key=field(args.requestKey,"Request key",100),prior=await cached(db,key);if(prior)return prior;
 const agent=role(args.agent);
 if(name==="hq_reply"){
  const text=field(args.text,"Reply",8000),mid=uid("msg");
  const statements=[stmt(db,"INSERT INTO messages(id,agent,role,text,status,created_at,request_key) VALUES(?,?,?,?,?,?,?)",mid,agent,agent,text,"delivered",now,key),event(db,agent,"reply",`${agent==="ceo"?"CEO":"HR"} replied`,text.slice(0,180),key,now)];
  if(args.replyTo){const message=id(args.replyTo),target=await one(db,"SELECT * FROM messages WHERE id=? AND agent=? AND role='founder'",message,agent);if(!target)throw new Problem(404,"Original message was not found for this agent.");statements.push(stmt(db,"UPDATE messages SET status='answered' WHERE id=?",message));}
  statements.push(stmt(db,"INSERT INTO settings(key,value) VALUES('last_agent_seen',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",now));
  return recordAction(db,key,{ok:true,id:mid,status:"delivered"},statements);
 }
 if(name==="hq_update_task"){
  const tid=id(args.id),task=await one(db,"SELECT * FROM tasks WHERE id=?",tid);if(!task)throw new Problem(404,"Task was not found.");
  if(task.owner!==agent)throw new Problem(403,"This task belongs to a different agent.");
  if(!task.approved_at)throw new Problem(403,"Founder approval is required before work begins.");
  const target=field(args.status,"Task status",20);if(!TRANSITIONS[task.status]?.includes(target))throw new Problem(409,"That task transition is not allowed.");
  let deliverable=task.deliverable,review=task.review_evidence;
  if(args.deliverable!==undefined)deliverable=field(args.deliverable,"Deliverable",12000);
  const reopening=task.status==="review"&&target==="running";
  if(reopening||deliverable!==task.deliverable)review=null;
  if(args.reviewEvidence!==undefined&&!reopening)review=field(args.reviewEvidence,"Review evidence",12000);
  if(target==="review"&&!deliverable)throw new Problem(400,"Provide the actual deliverable before review.");
  if(target==="completed"&&(!deliverable||!review))throw new Problem(400,"Deliverable and fresh recorded review evidence are required.");
  const detail=field(args.detail,"Activity detail",1500);
  return recordAction(db,key,{ok:true,id:tid,status:target},[stmt(db,"UPDATE tasks SET status=?,deliverable=?,review_evidence=?,updated_at=? WHERE id=?",target,deliverable,review,now,tid),event(db,agent,"task",`${task.title} · ${target}`,detail,key,now),stmt(db,"INSERT INTO settings(key,value) VALUES('last_agent_seen',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",now)]);
 }
 throw new Problem(400,"Unknown agent tool.");
}
const TOOLS=[
 {name:"hq_get_state",description:"Read the private Company HQ roster, queued messages, approved tasks and actual events. Agent roles remain on demand. Read the current authorized Brain separately before company answers.",inputSchema:{type:"object",properties:{},additionalProperties:false},annotations:{readOnlyHint:true}},
 {name:"hq_reply",description:"Post an actual CEO or HR reply to the private HQ after doing the scoped work. Do not invent executions or claim live Brain access. References alone do not authorize durable company learning.",inputSchema:{type:"object",properties:{agent:{type:"string",enum:["ceo","hr"]},text:{type:"string"},replyTo:{type:"string"},requestKey:{type:"string"}},required:["agent","text","requestKey"],additionalProperties:false}},
 {name:"hq_update_task",description:"Record actual progress on a founder-approved task. Cannot approve tasks, spend money, hire agents or change company rules. Completion requires an actual deliverable and fresh recorded review evidence. The authorized assistant must obtain independent review; this endpoint records supplied evidence and does not verify the reviewer's identity. Reopening work clears prior review evidence.",inputSchema:{type:"object",properties:{agent:{type:"string",enum:["ceo","hr"]},id:{type:"string"},status:{type:"string",enum:["queued","running","review","completed","blocked","failed"]},detail:{type:"string"},deliverable:{type:"string"},reviewEvidence:{type:"string"},requestKey:{type:"string"}},required:["agent","id","status","detail","requestKey"],additionalProperties:false}}
];
async function mcp(request,db){
 const rpc=await body(request),rid=rpc.id??null;
 if(rpc.method==="notifications/initialized")return new Response(null,{status:202});
 if(rpc.method==="server/discover")return response({jsonrpc:"2.0",id:rid,result:{supportedVersions:["2026-07-28"],capabilities:{tools:{}}}});
 if(rpc.method==="initialize")return response({jsonrpc:"2.0",id:rid,result:{protocolVersion:"2026-07-28",capabilities:{tools:{}},serverInfo:{name:"Building Suit Company HQ",version:"1.0.0"}}});
 if(rpc.method==="tools/list")return response({jsonrpc:"2.0",id:rid,result:{tools:TOOLS}});
 if(rpc.method!=="tools/call")return response({jsonrpc:"2.0",id:rid,error:{code:-32601,message:"Method not found"}});
 identity(request);
 if(request.headers.has("origin"))sameOrigin(request);
 if(!db)throw new Problem(503,"HQ storage is unavailable.");
 await seed(db);
 try{const data=await agentAction(db,rpc.params?.name,rpc.params?.arguments||{});return response({jsonrpc:"2.0",id:rid,result:{content:[{type:"text",text:JSON.stringify(data)}],structuredContent:data}});}catch(e){return response({jsonrpc:"2.0",id:rid,result:{isError:true,content:[{type:"text",text:e instanceof Problem?e.message:"HQ data could not be updated. No successful write is confirmed."}]}});}
}
export default {async fetch(request,env){
 try{
  const url=new URL(request.url);
  if(url.pathname==="/health")return response({ok:true,service:"company-hq",paidCallsEnabled:false});
  if(url.pathname==="/mcp"&&request.method==="POST")return await mcp(request,env.DB);
  identity(request);
  if(url.pathname==="/"&&request.method==="GET")return new Response(HTML,{headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"private, no-store","Content-Security-Policy":"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self' https://chatgpt.com https://chat.openai.com; form-action 'self'","X-Content-Type-Options":"nosniff","Referrer-Policy":"same-origin"}});
  if(url.pathname==="/favicon.ico")return new Response(null,{status:204});
  if(!env.DB)throw new Problem(503,"HQ storage is unavailable. Your action was not saved.");
  await seed(env.DB);
  if(url.pathname==="/api/state"&&request.method==="GET")return response(await state(env.DB));
  if(url.pathname==="/api/actions"&&request.method==="POST"){sameOrigin(request);return response(await founderAction(env.DB,await body(request)));}
  return response({ok:false,error:"Not found"},404);
 }catch(e){if(e instanceof Problem)return response({ok:false,error:e.message},e.status);console.error("HQ operation failed",e?.name);return response({ok:false,error:"HQ could not complete this action. Refresh before retrying; no successful write is confirmed."},500);}
}};
