import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import worker from '../worker/index.js';
import { LocalD1, applyMigration } from '../scripts/db-shim.mjs';

const origin = 'https://hq.example';
const migration = fileURLToPath(new URL('../drizzle/0000_hq.sql', import.meta.url));
function fixture(t) {
  const database = new LocalD1();
  applyMigration(database, migration);
  t.after(() => database.close());
  let counter = 0;
  const request = async (route, { body, authenticated = true, requestOrigin = origin, method } = {}) => {
    const headers = new Headers();
    if (authenticated) headers.set('oai-authenticated-user-id', 'test-founder');
    if (requestOrigin !== null) headers.set('Origin', requestOrigin);
    if (body !== undefined) headers.set('Content-Type', 'application/json');
    const response = await worker.fetch(new Request(origin + route, { method: method || (body === undefined ? 'GET' : 'POST'), headers, body: body === undefined ? undefined : JSON.stringify(body) }), { DB: database });
    return { status: response.status, body: await response.json() };
  };
  const action = (body, options) => request('/api/actions', { body: { idempotencyKey: `founder-${++counter}`, ...body }, ...options });
  const tool = async (name, args = {}, options) => request('/mcp', { body: { jsonrpc: '2.0', id: ++counter, method: 'tools/call', params: { name, arguments: { requestKey: `agent-${counter}`, ...args } } }, ...options });
  const create = (overrides = {}) => action({ action: 'create_task', title: 'Scoped HQ work', brief: 'Prepare a role assessment.', owner: 'ceo', acceptance: 'Source-backed brief with independent review.', allowedActions: 'Read assigned notes and write the brief.', budget: 0, ...overrides });
  const approve = (id) => action({ action: 'approve_task', id });
  const update = (id, status, args = {}) => tool('hq_update_task', { agent: 'ceo', id, status, detail: `Actual ${status} action`, ...args });
  const state = () => request('/api/state');
  return { database, request, action, tool, create, approve, update, state };
}
const toolData = (result) => result.body.result?.structuredContent;
const toolError = (result) => result.body.result?.isError === true;

test('private state and mutations require platform identity; health is public', async (t) => {
  const app = fixture(t);
  assert.equal((await app.request('/api/state', { authenticated: false })).status, 401);
  assert.equal((await app.action({ action: 'send_message', agent: 'ceo', text: 'Private' }, { authenticated: false })).status, 401);
  assert.equal((await app.tool('hq_get_state', {}, { authenticated: false })).status, 401);
  assert.equal((await app.request('/health', { authenticated: false })).status, 200);
});

test('founder mutations reject cross-site and missing origins', async (t) => {
  const app = fixture(t);
  const body = { action: 'send_message', agent: 'ceo', text: 'Do not save' };
  assert.equal((await app.action(body, { requestOrigin: 'https://other.example' })).status, 403);
  assert.equal((await app.action(body, { requestOrigin: null })).status, 403);
  const state = await app.state();
  assert.equal(state.body.messages.length, 0);
});

test('MCP tool calls reject a foreign browser origin and accept originless native clients', async (t) => {
  const app = fixture(t);
  const original = await app.action({ action: 'send_message', agent: 'hr', text: 'Assess a capability.' });
  const reply = { agent: 'hr', text: 'Forged cross-site reply', replyTo: original.body.id };
  assert.equal((await app.tool('hq_reply', reply, { requestOrigin: 'https://other.example' })).status, 403);
  assert.equal((await app.state()).body.messages.length, 1);
  const native = await app.tool('hq_reply', { ...reply, text: 'Actual native-client reply' }, { requestOrigin: null });
  assert.equal(toolData(native).status, 'delivered');
  assert.equal((await app.state()).body.messages.length, 2);
});

test('initial state contains exactly the real CEO, HR and reviewed historical task', async (t) => {
  const app = fixture(t);
  const { body } = await app.state();
  assert.deepEqual(body.agents.map((agent) => agent.id).sort(), ['ceo', 'hr']);
  assert.equal(body.tasks.length, 1);
  assert.equal(body.tasks[0].id, 'HR-001');
  assert.equal(body.tasks[0].status, 'completed');
  assert.match(body.tasks[0].reviewEvidence, /unavailable|limitation/i);
  assert.equal(body.messages.length, 0);
  assert.equal(body.connection.connected, false);
  assert.deepEqual(body.cost, { paidCallsEnabled: false, limit: 0 });
  assert.ok(body.agents.every((agent) => agent.status === 'idle'));
});

test('zero budget and existing workforce are enforced', async (t) => {
  const app = fixture(t);
  assert.equal((await app.create({ budget: 1 })).status, 400);
  assert.equal((await app.create({ budget: '0' })).status, 400);
  assert.equal((await app.create({ owner: 'builder' })).status, 400);
  assert.equal((await app.action({ action: 'send_message', agent: 'recruiter', text: 'New employee' })).status, 400);
  assert.equal((await app.state()).body.tasks.length, 1);
});

test('sending a message persists one queued record and never fabricates an agent reply', async (t) => {
  const app = fixture(t);
  const input = { action: 'send_message', agent: 'hr', text: 'Assess our skills', idempotencyKey: 'same-send' };
  const first = await app.action(input);
  const repeated = await app.action(input);
  assert.equal(first.status, 200);
  assert.deepEqual(repeated.body, first.body);
  const state = (await app.state()).body;
  assert.equal(state.messages.length, 1);
  assert.equal(state.messages[0].role, 'founder');
  assert.equal(state.messages[0].status, 'queued');
  assert.equal(state.events.filter((event) => event.type === 'message').length, 1);
  assert.equal(state.connection.connected, false);
  assert.equal(state.agents.find((agent) => agent.id === 'hr').status, 'idle');
});

test('agent work requires an approved plan and the correct owner', async (t) => {
  const app = fixture(t);
  const plan = await app.create();
  const id = plan.body.id;
  assert.equal(plan.body.status, 'proposed');
  assert.ok(toolError(await app.update(id, 'running')));
  assert.equal((await app.approve(id)).body.status, 'queued');
  assert.ok(toolError(await app.update(id, 'running', { agent: 'hr' })));
  assert.equal(toolData(await app.update(id, 'running')).status, 'running');
  assert.equal((await app.state()).body.agents.find((agent) => agent.id === 'ceo').status, 'working');
});

test('review and completion require actual artifacts and review evidence', async (t) => {
  const app = fixture(t);
  const id = (await app.create()).body.id;
  await app.approve(id);
  await app.update(id, 'running');
  assert.ok(toolError(await app.update(id, 'completed', { deliverable: 'Brief', reviewEvidence: 'Check' })));
  assert.ok(toolError(await app.update(id, 'review')));
  assert.equal(toolData(await app.update(id, 'review', { deliverable: 'Written staffing brief' })).status, 'review');
  assert.ok(toolError(await app.update(id, 'completed')));
  assert.equal(toolData(await app.update(id, 'completed', { reviewEvidence: 'Separate reviewer checked requirements and sources.' })).status, 'completed');
  assert.ok(toolError(await app.update(id, 'running')));
  const task = (await app.state()).body.tasks.find((task) => task.id === id);
  assert.equal(task.deliverable, 'Written staffing brief');
  assert.match(task.reviewEvidence, /Separate reviewer/);
});

test('reopening reviewed work discards prior review and requires a fresh review', async (t) => {
  const app = fixture(t);
  const id = (await app.create()).body.id;
  await app.approve(id);
  await app.update(id, 'running');
  await app.update(id, 'review', { deliverable: 'Artifact A', reviewEvidence: 'Independent review of A' });
  assert.equal(toolData(await app.update(id, 'running')).status, 'running');
  assert.equal((await app.state()).body.tasks.find((task) => task.id === id).reviewEvidence, null);
  await app.update(id, 'review', { deliverable: 'Changed artifact B' });
  assert.ok(toolError(await app.update(id, 'completed')));
  assert.equal(toolData(await app.update(id, 'completed', { reviewEvidence: 'Fresh independent review of B' })).status, 'completed');
  const task = (await app.state()).body.tasks.find((task) => task.id === id);
  assert.equal(task.deliverable, 'Changed artifact B');
  assert.equal(task.reviewEvidence, 'Fresh independent review of B');
});

test('a changed deliverable cannot be completed using the previous artifact review', async (t) => {
  const app = fixture(t);
  const id = (await app.create()).body.id;
  await app.approve(id);
  await app.update(id, 'running');
  await app.update(id, 'review', { deliverable: 'Artifact A', reviewEvidence: 'Independent review of A' });
  assert.ok(toolError(await app.update(id, 'completed', { deliverable: 'Changed artifact B' })));
  const unchanged = (await app.state()).body.tasks.find((task) => task.id === id);
  assert.equal(unchanged.status, 'review');
  assert.equal(unchanged.deliverable, 'Artifact A');
  assert.equal(toolData(await app.update(id, 'completed', { deliverable: 'Changed artifact B', reviewEvidence: 'Fresh independent review of B' })).status, 'completed');
});

test('cancellation prevents later agent work and closes its live status', async (t) => {
  const app = fixture(t);
  const id = (await app.create()).body.id;
  await app.approve(id);
  await app.update(id, 'running');
  assert.equal((await app.action({ action: 'cancel_task', id })).body.status, 'cancelled');
  assert.ok(toolError(await app.update(id, 'review', { deliverable: 'Late output' })));
  const state = (await app.state()).body;
  assert.equal(state.tasks.find((task) => task.id === id).status, 'cancelled');
  assert.equal(state.agents.find((agent) => agent.id === 'ceo').status, 'idle');
});

test('MCP replies are stored, scoped to the addressed role, and idempotent', async (t) => {
  const app = fixture(t);
  const original = await app.action({ action: 'send_message', agent: 'hr', text: 'Find an appropriate skill.' });
  assert.ok(toolError(await app.tool('hq_reply', { agent: 'ceo', text: 'Wrong recipient', replyTo: original.body.id })));
  const args = { agent: 'hr', text: 'Here is the actual assessment.', replyTo: original.body.id, requestKey: 'reply-once' };
  const first = await app.tool('hq_reply', args);
  const repeated = await app.tool('hq_reply', args);
  assert.equal(toolData(first).status, 'delivered');
  assert.deepEqual(toolData(repeated), toolData(first));
  const state = (await app.state()).body;
  assert.equal(state.messages.length, 2);
  assert.equal(state.messages.find((message) => message.id === original.body.id).status, 'answered');
  assert.equal(state.messages.filter((message) => message.role === 'hr').length, 1);
  assert.equal(state.connection.connected, true);
});

test('D1-compatible batches are atomic when a constraint fails', async (t) => {
  const app = fixture(t);
  await assert.rejects(app.database.batch([
    app.database.prepare("INSERT INTO settings(key,value) VALUES('transaction-check','first')"),
    app.database.prepare("INSERT INTO settings(key,value) VALUES('transaction-check','duplicate')"),
  ]));
  assert.equal(await app.database.prepare("SELECT value FROM settings WHERE key='transaction-check'").first(), null);
});

test('cancelling concurrently cannot be undone by a stale agent update', async (t) => {
  const app = fixture(t);
  const id = (await app.create()).body.id;
  await app.approve(id);
  const [cancelled] = await Promise.all([
    app.action({ action: 'cancel_task', id }),
    app.update(id, 'running'),
  ]);
  assert.equal(cancelled.body.status, 'cancelled');
  assert.equal((await app.state()).body.tasks.find((task) => task.id === id).status, 'cancelled');
});
