import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

function parameters(values) {
  return values.map((value) => {
    if (typeof value === 'boolean') return value ? 1 : 0;
    if (value === null || typeof value === 'string' || typeof value === 'number' || typeof value === 'bigint' || value instanceof Uint8Array) return value;
    throw new TypeError('Unsupported local D1 binding value.');
  });
}

class Statement {
  constructor(database, sql, values = []) {
    this.database = database;
    this.sql = sql;
    this.values = values;
  }

  bind(...values) {
    return new Statement(this.database, this.sql, parameters(values));
  }

  execute(mode = 'auto') {
    const statement = this.database.prepare(this.sql);
    const isQuery = mode === 'all' || (mode === 'auto' && statement.columns().length > 0);
    if (isQuery) {
      const results = statement.all(...this.values).map((row) => ({ ...row }));
      return { success: true, results, meta: { changes: 0, rows_read: results.length } };
    }
    const result = statement.run(...this.values);
    return {
      success: true,
      results: [],
      meta: { changes: Number(result.changes), last_row_id: Number(result.lastInsertRowid), rows_written: Number(result.changes) },
    };
  }

  async first(column) {
    const statement = this.database.prepare(this.sql);
    const row = statement.get(...this.values);
    if (row === undefined) return null;
    const record = { ...row };
    return column === undefined ? record : (record[column] ?? null);
  }

  async all() {
    return this.execute('all');
  }

  async run() {
    return this.execute();
  }
}

/** A deliberately small D1-compatible adapter, used only by local preview/tests. */
export class LocalD1 {
  constructor(filename = ':memory:') {
    this.database = new DatabaseSync(filename);
    this.database.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
    if (filename !== ':memory:') this.database.exec('PRAGMA journal_mode=WAL;');
  }

  prepare(sql) {
    return new Statement(this.database, sql);
  }

  async batch(statements) {
    this.database.exec('BEGIN IMMEDIATE');
    try {
      // Execute synchronously inside the transaction; yielding here would allow
      // overlapping requests to enter a transaction on the same connection.
      const results = statements.map((statement) => {
        if (!(statement instanceof Statement) || statement.database !== this.database) throw new TypeError('Invalid local D1 batch statement.');
        return statement.execute();
      });
      this.database.exec('COMMIT');
      return results;
    } catch (error) {
      this.database.exec('ROLLBACK');
      throw error;
    }
  }

  async exec(sql) {
    this.database.exec(sql);
    return { count: 0, duration: 0 };
  }

  close() {
    this.database.close();
  }
}

export function applyMigration(database, migrationPath) {
  const sql = readFileSync(migrationPath, 'utf8');
  const name = new URL(`file:///${String(migrationPath).replaceAll('\\', '/')}`).pathname.split('/').at(-1);
  const hash = createHash('sha256').update(sql).digest('hex');
  const sqlite = database.database;
  sqlite.exec('CREATE TABLE IF NOT EXISTS _hq_local_migrations (name TEXT PRIMARY KEY, sha256 TEXT NOT NULL)');
  const existing = sqlite.prepare('SELECT sha256 FROM _hq_local_migrations WHERE name=?').get(name);
  if (existing) {
    if (existing.sha256 !== hash) throw new Error(`Local migration ${name} changed after it was applied. Preserve the existing database and use a new migration.`);
    return false;
  }
  sqlite.exec('BEGIN IMMEDIATE');
  try {
    sqlite.exec(sql);
    sqlite.prepare('INSERT INTO _hq_local_migrations(name,sha256) VALUES(?,?)').run(name, hash);
    sqlite.exec('COMMIT');
    return true;
  } catch (error) {
    sqlite.exec('ROLLBACK');
    throw error;
  }
}
