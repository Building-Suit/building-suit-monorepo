import { createServer } from 'node:http';
import { mkdir, access } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import { LocalD1, applyMigration } from './db-shim.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const port = Number(process.env.HQ_PORT || 8787);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('HQ_PORT must be an integer from 1024 to 65535.');
const workerPath = path.join(root, 'dist/server/index.js');
try {
  await access(workerPath);
} catch {
  throw new Error('Build Company HQ first: npm run build');
}

await mkdir(path.join(root, '.sites-runtime'), { recursive: true });
const database = new LocalD1(path.join(root, '.sites-runtime/hq.sqlite'));
applyMigration(database, path.join(root, 'drizzle/0000_hq.sql'));
const worker = (await import(pathToFileURL(workerPath).href)).default;

const server = createServer(async (incoming, outgoing) => {
  try {
    if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(incoming.socket.remoteAddress)) {
      outgoing.writeHead(403).end('Local preview accepts loopback requests only.');
      return;
    }
    const allowedHosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`]);
    if (!allowedHosts.has(incoming.headers.host)) {
      outgoing.writeHead(403).end('Use the printed loopback preview URL.');
      return;
    }
    const headers = new Headers();
    for (const [name, values] of Object.entries(incoming.headers)) {
      if (values !== undefined && name !== 'oai-authenticated-user-id') headers.set(name, Array.isArray(values) ? values.join(', ') : values);
    }
    // This identity is injected solely by the loopback development server.
    // Production worker code continues to require the hosting platform's identity.
    headers.set('oai-authenticated-user-id', 'local-founder');
    const chunks = [];
    let size = 0;
    for await (const chunk of incoming) {
      size += chunk.length;
      if (size > 18000) {
        outgoing.writeHead(413).end('Request is too large.');
        return;
      }
      chunks.push(chunk);
    }
    const method = incoming.method || 'GET';
    const body = !['GET', 'HEAD'].includes(method) && size ? Buffer.concat(chunks) : undefined;
    const request = new Request(`http://${incoming.headers.host}${incoming.url}`, { method, headers, body });
    const result = await worker.fetch(request, { DB: database });
    outgoing.writeHead(result.status, Object.fromEntries(result.headers));
    outgoing.end(Buffer.from(await result.arrayBuffer()));
  } catch (error) {
    console.error('Local HQ request failed:', error?.message || error?.name);
    if (!outgoing.headersSent) outgoing.writeHead(500, { 'Content-Type': 'text/plain' });
    outgoing.end('Local HQ request failed; inspect the development terminal.');
  }
});

server.on('error', (error) => {
  console.error(`Could not start local HQ: ${error.message}`);
  database.close();
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log(`Company HQ preview: http://127.0.0.1:${port}`);
  console.log('Local founder session only. Data: ignored .sites-runtime/hq.sqlite. Paid calls disabled.');
});
function stop() {
  server.close(() => {
    database.close();
    process.exit(0);
  });
}
process.once('SIGINT', stop);
process.once('SIGTERM', stop);
