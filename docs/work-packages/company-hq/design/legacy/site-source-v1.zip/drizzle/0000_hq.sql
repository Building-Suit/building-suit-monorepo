CREATE TABLE tasks (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, brief TEXT NOT NULL, owner TEXT NOT NULL CHECK(owner IN ('ceo','hr')),
 status TEXT NOT NULL CHECK(status IN ('proposed','queued','running','review','completed','blocked','failed','cancelled')),
 acceptance TEXT NOT NULL, allowed_actions TEXT NOT NULL, budget INTEGER NOT NULL DEFAULT 0 CHECK(budget=0),
 deliverable TEXT, review_evidence TEXT, approved_at TEXT, approval_source TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE messages (
 id TEXT PRIMARY KEY, agent TEXT NOT NULL CHECK(agent IN ('ceo','hr')), role TEXT NOT NULL CHECK(role IN ('founder','ceo','hr')),
 text TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, request_key TEXT UNIQUE NOT NULL
);
--> statement-breakpoint
CREATE TABLE events (
 id TEXT PRIMARY KEY, agent TEXT NOT NULL, type TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL,
 created_at TEXT NOT NULL, source_key TEXT UNIQUE NOT NULL
);
--> statement-breakpoint
CREATE TABLE actions (id TEXT PRIMARY KEY, result TEXT NOT NULL, created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
--> statement-breakpoint
CREATE INDEX messages_agent_date ON messages(agent,created_at);
--> statement-breakpoint
CREATE INDEX events_date ON events(created_at);
--> statement-breakpoint
CREATE TRIGGER task_status_guard BEFORE UPDATE OF status ON tasks
WHEN NOT (
 (OLD.status='proposed' AND NEW.status IN ('queued','cancelled')) OR
 (OLD.status='queued' AND NEW.status IN ('running','blocked','failed','cancelled')) OR
 (OLD.status='running' AND NEW.status IN ('review','blocked','failed','cancelled')) OR
 (OLD.status='review' AND NEW.status IN ('running','completed','blocked','failed','cancelled')) OR
 (OLD.status='blocked' AND NEW.status IN ('queued','failed','cancelled')) OR
 (OLD.status='failed' AND NEW.status='cancelled')
)
BEGIN SELECT RAISE(ABORT,'Invalid task status transition'); END;
--> statement-breakpoint
CREATE TRIGGER task_evidence_guard BEFORE UPDATE OF status ON tasks
WHEN (NEW.status NOT IN ('proposed','cancelled') AND NEW.approved_at IS NULL)
 OR (NEW.status IN ('review','completed') AND (NEW.deliverable IS NULL OR length(trim(NEW.deliverable))=0))
 OR (NEW.status='completed' AND (NEW.review_evidence IS NULL OR length(trim(NEW.review_evidence))=0))
BEGIN SELECT RAISE(ABORT,'Task approval or evidence is missing'); END;
